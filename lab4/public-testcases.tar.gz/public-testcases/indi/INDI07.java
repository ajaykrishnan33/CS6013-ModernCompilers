// No 
// Yes
// No 
// Yes
class INDI07 {
	public static void main (String [] args) {
		int x;
		int e;
		int t1;
		int t2;
		int t3;
		int t4;
		int size;
		int [] arr;
		size = 1000;
		arr = new int [size];
		/* INDEPENDENTITERS? */
		for (x = 2; x < 3; x = x + 1) {
			t3 = 0 * x;
			t4 = 5 * x;
			t1 = t3 + 10;
			t2 = t4 - 10;
			arr[t1] = 5;
			e = arr[t2];
		}
		/* INDEPENDENTITERS? */
		for (x = 0; x < 10; x = x + 1) {
		}
		/* INDEPENDENTITERS? */
		for (x = 2; x < 3; x = x + 1) {
			t3 = 0 * x;
			t4 = 5 * x;
			t1 = t3 + 10;
			t2 = t4 - 10;
			arr[t1] = 5;
			e = arr[t2];
		}
		/* INDEPENDENTITERS? */
		for (x = 0; x < 10; x = x + 1) {
		}
	}
}
