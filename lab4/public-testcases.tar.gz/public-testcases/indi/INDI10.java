// Yes
// No 
// Yes
class INDI10 {
	public static void main (String [] args) {
		int x;
		int e;
		int t1;
		int t2;
		int t3;
		int t4;
		int size;
		int [] arr;
		size = 1000;
		arr = new int [size];
		/* INDEPENDENTITERS? */
		for (x = 0; x < 10; x = x + 1) {
		}
		/* INDEPENDENTITERS? */
		for (x = 0; x < 10; x = x + 1) {
			t4 = 2 * 2;
			t3 = 2 * x;
			t2 = t3 + t4;
			t2 = t2 + x;
			e = arr[t2];
			
			t4 = 3 * x;	
			t1 = t4 - t3;
			t4 = 10 * 1;
			t1 = t1 + t4;
			t1 = t1 + x;
			t1 = t1 + 2;
			arr[t1] = 5;
		}
		/* INDEPENDENTITERS? */
		for (x = 0; x < 10; x = x + 1) {
		}
	}
}
