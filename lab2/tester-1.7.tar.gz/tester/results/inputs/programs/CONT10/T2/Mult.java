class Mult
{
	public static void main(String[] a) {
	    System.out.println(2*(3*6));
    }
}
