//Testcase for print statement and expression(AND)
class testcase1 {
public static void main(String[] args) {
	System.out.println( true&false );
}
}

