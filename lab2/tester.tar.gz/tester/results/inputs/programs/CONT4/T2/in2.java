class in2
{
public static void main(String [] args)
{
System.out.println(0);
}
}
class Vehicle
{
public int print()
{
System.out.println(1);
System.out.println(2);
return 0;
}
}
