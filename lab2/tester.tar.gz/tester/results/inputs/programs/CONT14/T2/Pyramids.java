class Pyramids {
	public static void main(String[] args) {
	         System.out.println(new BuildPyramid().Display(20));
	        }
}

class BuildPyramid{

	public int Display(int num){	
	int i;
	int j;
	for ( i = 1; i <20; i=i+1) {
		for ( j = 1; j < 20; j=j+1) {
                	System.out.println(0);
            		}
            }
       return 0;
       }
}
            
            
