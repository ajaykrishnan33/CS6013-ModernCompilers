
class P1 {
   public static void main(String [] args) {
      System.out.println(new A().A_func(20));
   }
}

class A {
	int i;
    public int A_func(int num){
    	int j;
    	boolean k;
    	int n;
    	n = 0;
    	k = false;
        if (5 < num) {
        	j = 10; 
		}
        else {
        	j = 15;
		}
        for (i = 0; i < j; i = (i + j)- 2) {
			while(!(k & true))
			{
				k = !k;
				n = n + 1;
			}
			
		}
        
        return n;
    }
}
