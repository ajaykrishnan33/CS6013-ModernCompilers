
        
class P5 {
   public static void main(String [] args) {
      System.out.println(new C().C_func(5));
   }
}

class C {
	public int C_func(int num) {
		int num_aux ;
        if (num < 1)
            num_aux = 0 ;
        else
            num_aux = num + (this.C_func(num-1)) ;
        return num_aux ;
	}
}
	
