

class P3 {
   public static void main(String [] args) {
      System.out.println(new C().C_func());
   }
}

class C {
	public int C_func() {
		int i;
		A a;
		i = 5;
		a = new A();
		return a.A_func(new A().A_func(i,0), new A().A_func(i + 5, 0));
	}
}

class A {
	
    public int A_func(int num,int j){
    	num = num + j;
    	return num;
    }
}
