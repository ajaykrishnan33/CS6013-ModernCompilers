

class P2 {
   public static void main(String [] args) {
      System.out.println(new C().C_func());
   }
}

class C {
	public int C_func() {
		B b;
		int i;
		i = 5;
		b = new B();
		return this.C_2(b,i);
	}
	public int C_2(A obj,int i) {
		return obj.A_func(i);
	}
}

class B extends A{
	public int B_func(int num) {
		num = num + 5;
		return num;
	}
}

class A {
	
    public int A_func(int num){
    	num = num + 10;
    	return num;
    }
}
