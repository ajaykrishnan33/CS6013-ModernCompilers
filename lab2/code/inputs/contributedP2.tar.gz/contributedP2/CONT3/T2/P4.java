

class P4 {
   public static void main(String [] args) {
      System.out.println(new C().C_func());
   }
}

class C {
	public int C_func() {
		int[] a;
		int[] b;
		a = new int[1];
		a[0] = 0;
		b = new int[2];
		b[0] = a[0];
		b[1] = (b[(a[0])]) + 1;
		return b[(b[1])];
	}
}
