class Fibonacci{  
	public static void main(String[] a)  
	{  
	System.out.println(new Fib().PrintFib(15));
	}
}

class Fib{

public int PrintFib(int n) {
	int x;
	int y;
    	if(n < 1) 
    	    x=1;        
    	else 
    	    x = this.PrintFib(n - 1);
    	    y = this.PrintFib(n - 2);
    	    x = x+y;
    	if(n < 2)
    	   x=1;
    	else { }
    	return x;
	}
} 


