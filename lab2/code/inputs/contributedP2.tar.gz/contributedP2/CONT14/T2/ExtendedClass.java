class ExtendedClass{
    public static void main(String[] a){
        System.out.println(new Shape().ComputeFac(10));
    }
}

class Shape {

    int sides;

    public boolean print(){
        System.out.println(1);
        return true;
    }

}

class Circle extends Shape {

   int radius;
 
}
