class Nested {
	public static void main( String[] args ) {
		System.out.println( ( ((((new A()).t()).a()).a()).o()) );
	}
}

class A {
	boolean b;
	public A a() { b=!b; return this; }
	public A t() { b=true; return this; }
	public int o() {
		int val;
		val=0;
		while(b) { val=val+1; b=!b; }
		return val;
	}
}