class Expression {
	public static void main( String[] Strings ) {
		//System.out.println( (new A().a()) );
		System.out.println( (new A().a()) - ( (new B().a()) * ((new B().b()) + (new A().b())) ) );
	}
}

class A {
	public int a() { return 10; }
	public int b() { return 20; }
}

class B {
	public int a() { return 30; }
	public int b() { return 40; }
}