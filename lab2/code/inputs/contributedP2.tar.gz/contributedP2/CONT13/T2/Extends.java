class Extends {
	public static void main(String[] strs) {
		System.out.println( (new B()).g() );
	}
}

class A {
	int i;
	public int ii() { int j; j=i; return j; }
	public int f() {
		int i; int j;
		i=10; this.i=0;
		this.i = (i*i) + (i*(this.ii()));
		j = this.ii();
		return j;
	}
}

class B extends A {
	int i;
	public int g() { this.i=1; return i+(this.f()) ; }
}