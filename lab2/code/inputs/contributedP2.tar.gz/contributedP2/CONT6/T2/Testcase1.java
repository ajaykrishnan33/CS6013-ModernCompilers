class Testcase1 {
	public static void main (String [] args) {
		System.out.println(new B().f1(20));
	}
}	
	class B extends Testcase1
	{
		int sum;
		int i;
		

		public int f1(int y)
		{
			sum=0;
			for(i=0;i<20;i=y)
				{sum = sum+i;
				i = i+1;
				}
			return sum;
		}
		
	}

