class Testcase2 {
	public static void main (String [] args) {
		System.out.println(new T2().hcf(12,48));
	}
	

}

class T2 
{
public int hcf(int n1, int n2)
{
	int gcd;
	int rem;
    if (n2 < 1)
       gcd = n1;
    else 
    {
    	rem = this.remainder(n1,n2);
       gcd = this.hcf(n2, rem);}
    	return gcd;
}

public int remainder(int num,int divisor)
{
	int product;
	int i;
	i=1;
	product=0;
	while (product < num)
    {
        product = divisor * i;
        i=i+1;
    }
 
    // return remainder
    return num - (product - divisor);
}
}
