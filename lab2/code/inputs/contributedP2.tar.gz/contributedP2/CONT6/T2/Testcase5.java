class Testcase5 {
	public static void main (String [] args) {
		System.out.println(new B().multiply(4,5));
	}
}
class B extends Testcase5
{

public int multiply(int x, int y)
{
   int n;
  
   n=0;
 
      y = y-1;
     n = this.multiply(x, y);
     n = x + n;
return n;
}
}
