class Testcase3 {

	public static void main(String[] args) {
		System.out.println(new Divide().dividefunction(5, 50));
	}
}
class Divide
{
	int count;
	public int dividefunction(int n1,int n2)
	{
		while(n1<n2)
		{
			n2 = n2 -n1;
			count=count+1;
		}
		return count;
	}

}
