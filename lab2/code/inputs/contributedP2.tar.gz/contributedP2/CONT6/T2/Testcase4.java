class Testcase4 {

	public static void main(String[] args) {
		System.out.println(new Prime().prime(7));
	}
	
}

	class Prime{
		
	public boolean prime(int n)
	{ int i;
	  boolean flag;	
	  int rem;
	  flag = true;
			
	  n = new Divide().dividefunction(2,n);
	  
	  for(i=2; i<n; i = i+1){
        rem = new T2().remainder(n,i);
        if(0<rem)
        {
        }
        else
        {

            flag=false;
       
        }
    }
	return flag;
	}
}
