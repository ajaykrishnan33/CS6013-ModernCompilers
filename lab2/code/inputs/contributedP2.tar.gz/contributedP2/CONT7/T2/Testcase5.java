class Testcase5 {

	public static void main(String[] args) {
		
		System.out.println(new T5().Fun(3, 4));

	}

}

class T5 extends Testcase5{
	
int p;
int t1;
int t2;
int t3;
    public int Fun(int m, int n) {

     if (m < 1) {
      p = 2 * n;
     } 
     else 
     {
      if (1 < m) {
      if (n < 1) {
       p = 0;
      }
      else{
    	  
      }}
      else{
    	  
      }
     }
     
      if (n <2) {
       p = 2;
      } else {
    	  t1 = m-1;
    	  t2 = n-1;
    	  t3 =  this.Fun(m,t2);
       p = this.Fun(t1,t3);
      }
     
     
     return p; 
    }
}
