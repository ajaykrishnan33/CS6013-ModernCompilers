package helper;
import java.io.*;
import java.util.*;

public class AliasQuery{
	public String var1;
	public String var2;
	public BlockLine block;

	public AliasQuery(String x, String y, BlockLine b){
		var1 = x;
		var2 = y;
		block = b;
	}

}