class Square{
    public static void main(String[] a){
        b var1;
        int t;

        var1=new b();
        /*INLINE*/
        t=var1.tp();
        System.out.println(t);
    }
}

class arraysquare 
{
    public int sqr()
    {
        int sum;
        int j;

        int [] anArray;
        j=0;


        return j;
    }



}

class a extends arraysquare
{
    public int sqr()
    {
        int c;
        c=9;
        return c;
    }


}

class b
{
    public int tp()
    {
        arraysquare var1;
        int c;
        var1=new a();
        /*INLINE*/
        c=var1.sqr();
        return c;
    }
}
