
class Arr
{
    public static void main(String[] a) {
        int res;
        int two;
        int thr;
        art g;
        g = new art();
        two = 2;
        thr =3;

        /* INLINE */ res = g.t3(two,thr);
        System.out.println(res);
    }
}
class art
{
    public int t3(int x, int y) {
        int[] d;
        int t1;
        int t2;
        int t3;
        int t4;
        int t5;
        int t6;
        int tw;
        int on;
        int fi;
        int ss;
        fi = 5;
        tw = 20;
        on = 1;
        d = new int[tw];
        t3 = x+y;
        t4 = y-x;
        ss = 67;
        d[t3] = ss;
        ss = 45;
        d[x]= ss;
        ss = 69;
        d[on] = ss;
        t5 = d[fi];
        t6 = d[x];
        t1 = t5 + t6;
        System.out.println(t1);
        t2 = d[t4];
        System.out.println(t2);
        return on;
    }
}
