class Test3 { 
public static void main ( String [ ] args ) { 
Test3Aux p2 ; 
int q3 ; 
int r4 ; 
int Test3_n17 ; 
Test3Aux main_Test3Aux_temp5 ; 
int main_Test3Aux_temp9 ; 
Test3Aux main_Test3Aux_temp8 ; 
int main_Test3Aux_temp6 ; 
int int_temp1 ;
int int_temp2 ;
int int_temp3 ;
int int_temp4 ;
boolean boolean_temp1 ;
boolean boolean_temp2 ;
boolean boolean_temp3 ;
boolean boolean_temp4 ;
int[] intarr_temp1 ;
int[] intarr_temp2 ;
int[] intarr_temp3 ;
int[] intarr_temp4 ;
Test3Aux Test3Aux_temp1 ;
Test3Aux Test3Aux_temp2 ;
Test3Aux Test3Aux_temp3 ;
Test3Aux Test3Aux_temp4 ;
Test3 Test3_temp1 ;
Test3 Test3_temp2 ;
Test3 Test3_temp3 ;
Test3 Test3_temp4 ;
int_temp1 = 5;
q3 = int_temp1;
Test3Aux_temp1 = new Test3Aux();
p2 = Test3Aux_temp1;
Test3Aux_temp1 = p2;
int_temp1 = Test3Aux_temp1.func1();
; 
Test3_n17 = q3;
main_Test3Aux_temp8 = p2 ; 
int_temp4 = main_Test3Aux_temp8.x0;
int_temp3 = int_temp4 + Test3_n17 ; 
int_temp2 = int_temp3; 
main_Test3Aux_temp8.x0 = int_temp2;
main_Test3Aux_temp9 = Test3_n17 ; 
q3 = main_Test3Aux_temp9;
System.out.println ( q3) ; 
main_Test3Aux_temp5 = p2 ; 
main_Test3Aux_temp6 = main_Test3Aux_temp5.x0 ; 
r4 = main_Test3Aux_temp6;
System.out.println ( r4) ; 
} 
} 
class Test3Aux { 
int x0 ; 
public int func1 ( ) { 
int int_temp1 ;
int int_temp2 ;
int int_temp3 ;
int int_temp4 ;
boolean boolean_temp1 ;
boolean boolean_temp2 ;
boolean boolean_temp3 ;
boolean boolean_temp4 ;
int[] intarr_temp1 ;
int[] intarr_temp2 ;
int[] intarr_temp3 ;
int[] intarr_temp4 ;
Test3Aux Test3Aux_temp1 ;
Test3Aux Test3Aux_temp2 ;
Test3Aux Test3Aux_temp3 ;
Test3Aux Test3Aux_temp4 ;
Test3 Test3_temp1 ;
Test3 Test3_temp2 ;
Test3 Test3_temp3 ;
Test3 Test3_temp4 ;
int_temp1 = 5;
x0 = int_temp1;
return x0 ; 
} 
public int func2 ( int n1 ) { 
int int_temp1 ;
int int_temp2 ;
int int_temp3 ;
int int_temp4 ;
boolean boolean_temp1 ;
boolean boolean_temp2 ;
boolean boolean_temp3 ;
boolean boolean_temp4 ;
int[] intarr_temp1 ;
int[] intarr_temp2 ;
int[] intarr_temp3 ;
int[] intarr_temp4 ;
Test3Aux Test3Aux_temp1 ;
Test3Aux Test3Aux_temp2 ;
Test3Aux Test3Aux_temp3 ;
Test3Aux Test3Aux_temp4 ;
Test3 Test3_temp1 ;
Test3 Test3_temp2 ;
Test3 Test3_temp3 ;
Test3 Test3_temp4 ;
int_temp1 = x0 + n1 ; 
x0 = int_temp1;
return n1 ; 
} 
public int func3 ( ) { 
int int_temp1 ;
int int_temp2 ;
int int_temp3 ;
int int_temp4 ;
boolean boolean_temp1 ;
boolean boolean_temp2 ;
boolean boolean_temp3 ;
boolean boolean_temp4 ;
int[] intarr_temp1 ;
int[] intarr_temp2 ;
int[] intarr_temp3 ;
int[] intarr_temp4 ;
Test3Aux Test3Aux_temp1 ;
Test3Aux Test3Aux_temp2 ;
Test3Aux Test3Aux_temp3 ;
Test3Aux Test3Aux_temp4 ;
Test3 Test3_temp1 ;
Test3 Test3_temp2 ;
Test3 Test3_temp3 ;
Test3 Test3_temp4 ;
return x0 ; 
} 
} 
 