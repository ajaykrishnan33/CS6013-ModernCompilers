class Find_Gcd { 
public static void main ( String [ ] a ) { 
int main_Gcd_temp27 ; 
Gcd main_Gcd_temp26 ; 
boolean Find_Gcd_findgcd_Gcd_temp1621 ; 
boolean Find_Gcd_Gcd_retval91122 ; 
Gcd m3 ; 
boolean Find_Gcd_a417 ; 
int Find_Gcd_n1518 ; 
int Find_Gcd_n2619 ; 
Gcd Find_Gcd_findgcd_Gcd_temp1520 ; 
int x0 ; 
int y1 ; 
int z2 ; 
int Find_Gcd_Gcd_aux0281423 ; 
int Find_Gcd_Gcd_num171324 ; 
int Find_Gcd_Gcd_num2101225 ; 
int int_temp1 ;
int int_temp2 ;
int int_temp3 ;
int int_temp4 ;
boolean boolean_temp1 ;
boolean boolean_temp2 ;
boolean boolean_temp3 ;
boolean boolean_temp4 ;
int[] intarr_temp1 ;
int[] intarr_temp2 ;
int[] intarr_temp3 ;
int[] intarr_temp4 ;
Find_Gcd Find_Gcd_temp1 ;
Find_Gcd Find_Gcd_temp2 ;
Find_Gcd Find_Gcd_temp3 ;
Find_Gcd Find_Gcd_temp4 ;
Gcd Gcd_temp1 ;
Gcd Gcd_temp2 ;
Gcd Gcd_temp3 ;
Gcd Gcd_temp4 ;
int_temp1 = 10;
x0 = int_temp1;
int_temp1 = 15;
y1 = int_temp1;
Gcd_temp1 = new Gcd();
m3 = Gcd_temp1;
Find_Gcd_n1518 = x0;
Find_Gcd_n2619 = y1;
main_Gcd_temp26 = m3 ; 
Find_Gcd_Gcd_num171324 = Find_Gcd_n1518;
Find_Gcd_Gcd_num2101225 = Find_Gcd_n2619;
Find_Gcd_findgcd_Gcd_temp1520 = main_Gcd_temp26 ; 
boolean_temp1 = false;
Find_Gcd_Gcd_retval91122 = boolean_temp1;
int_temp1 = Find_Gcd_Gcd_num2101225;
Find_Gcd_Gcd_aux0281423 = int_temp1;
Find_Gcd_findgcd_Gcd_temp1621 = Find_Gcd_Gcd_retval91122 ; 
Find_Gcd_a417 = Find_Gcd_findgcd_Gcd_temp1621;
while ( Find_Gcd_a417) {
if ( Find_Gcd_a417) {
int_temp1 = Find_Gcd_n1518 - Find_Gcd_n2619 ; 
Find_Gcd_n1518 = int_temp1;
}
else {
int_temp1 = Find_Gcd_n2619 - Find_Gcd_n1518 ; 
Find_Gcd_n2619 = int_temp1;
}
}
main_Gcd_temp27 = Find_Gcd_n1518 ; 
z2 = main_Gcd_temp27;
System.out.println ( z2) ; 
} 
} 
class Gcd { 
public int findgcd ( int n15 , int n26 ) { 
boolean Gcd_retval911 ; 
boolean a4 ; 
int Gcd_num21012 ; 
Gcd findgcd_Gcd_temp15 ; 
int Gcd_num1713 ; 
boolean findgcd_Gcd_temp16 ; 
int Gcd_aux02814 ; 
int int_temp1 ;
int int_temp2 ;
int int_temp3 ;
int int_temp4 ;
boolean boolean_temp1 ;
boolean boolean_temp2 ;
boolean boolean_temp3 ;
boolean boolean_temp4 ;
int[] intarr_temp1 ;
int[] intarr_temp2 ;
int[] intarr_temp3 ;
int[] intarr_temp4 ;
Find_Gcd Find_Gcd_temp1 ;
Find_Gcd Find_Gcd_temp2 ;
Find_Gcd Find_Gcd_temp3 ;
Find_Gcd Find_Gcd_temp4 ;
Gcd Gcd_temp1 ;
Gcd Gcd_temp2 ;
Gcd Gcd_temp3 ;
Gcd Gcd_temp4 ;
Gcd_num1713 = n15;
Gcd_num21012 = n26;
findgcd_Gcd_temp15 = this ; 
boolean_temp1 = false;
Gcd_retval911 = boolean_temp1;
int_temp1 = Gcd_num21012;
Gcd_aux02814 = int_temp1;
findgcd_Gcd_temp16 = Gcd_retval911 ; 
a4 = findgcd_Gcd_temp16;
while ( a4) {
if ( a4) {
int_temp1 = n15 - n26 ; 
n15 = int_temp1;
}
else {
int_temp1 = n26 - n15 ; 
n26 = int_temp1;
}
}
return n15 ; 
} 
public boolean Compare ( int num17 , int num210 ) { 
int aux028 ; 
boolean retval9 ; 
int int_temp1 ;
int int_temp2 ;
int int_temp3 ;
int int_temp4 ;
boolean boolean_temp1 ;
boolean boolean_temp2 ;
boolean boolean_temp3 ;
boolean boolean_temp4 ;
int[] intarr_temp1 ;
int[] intarr_temp2 ;
int[] intarr_temp3 ;
int[] intarr_temp4 ;
Find_Gcd Find_Gcd_temp1 ;
Find_Gcd Find_Gcd_temp2 ;
Find_Gcd Find_Gcd_temp3 ;
Find_Gcd Find_Gcd_temp4 ;
Gcd Gcd_temp1 ;
Gcd Gcd_temp2 ;
Gcd Gcd_temp3 ;
Gcd Gcd_temp4 ;
boolean_temp1 = false;
retval9 = boolean_temp1;
int_temp1 = num210;
aux028 = int_temp1;
return retval9 ; 
} 
} 
 