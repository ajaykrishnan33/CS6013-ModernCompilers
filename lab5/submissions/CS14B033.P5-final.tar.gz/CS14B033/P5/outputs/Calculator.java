class Calculator { 
public static void main ( String [ ] a ) { 
int x5 ; 
int y6 ; 
int z7 ; 
My_Calculation m8 ; 
x5 = 40 ; 
y6 = 37 ; 
m8 = new My_Calculation ( ) ; 
z7 = m8 . Start ( x5 , y6 ) ; 
System.out.println ( z7 ) ; 
} 
} 
class Calculation { 
int z9 ; 
public int addition ( int x12 , int y13 ) { 
z9 = x12 + y13 ; 
System.out.println ( z9 ) ; 
return z9 ; 
} 
public int Subtraction ( int x10 , int y11 ) { 
z9 = x10 - y11 ; 
System.out.println ( z9 ) ; 
return z9 ; 
} 
} 
class My_Calculation extends Calculation { 
public int multiplication ( int x3 , int y4 ) { 
z9 = x3 * y4 ; 
return z9 ; 
} 
public int Start ( int a0 , int b1 ) { 
Calculation Start_Calculation_temp24 ; 
int Start_Calculation_temp25 ; 
int Start_My_Calculation_temp17 ; 
Calculation Start_Calculation_temp20 ; 
int Start_Calculation_temp21 ; 
My_Calculation Start_My_Calculation_temp16 ; 
int My_Calculation_x1018 ; 
int x2 ; 
int My_Calculation_y1119 ; 
int My_Calculation_x1222 ; 
int My_Calculation_y1323 ; 
int My_Calculation_x314 ; 
int My_Calculation_y415 ; 
My_Calculation_x1222 = a0;
My_Calculation_y1323 = b1;
Start_Calculation_temp24 = new Calculation() ; 
Start_Calculation_temp24.z9 = My_Calculation_x1222 + My_Calculation_y1323 ; 
System.out.println ( Start_Calculation_temp24.z9 ) ; 
Start_Calculation_temp25 = Start_Calculation_temp24.z9 ; 
x2 = Start_Calculation_temp25 ; 
My_Calculation_x1018 = a0;
My_Calculation_y1119 = b1;
Start_Calculation_temp20 = new Calculation() ; 
Start_Calculation_temp20.z9 = My_Calculation_x1018 - My_Calculation_y1119 ; 
System.out.println ( Start_Calculation_temp20.z9 ) ; 
Start_Calculation_temp21 = Start_Calculation_temp20.z9 ; 
x2 = Start_Calculation_temp21 ; 
My_Calculation_x314 = a0;
My_Calculation_y415 = b1;
Start_My_Calculation_temp16 = this ; 
Start_My_Calculation_temp16.z9 = My_Calculation_x314 * My_Calculation_y415 ; 
Start_My_Calculation_temp17 = Start_My_Calculation_temp16.z9 ; 
x2 = Start_My_Calculation_temp17 ; 
return x2 ; 
} 
} 
 