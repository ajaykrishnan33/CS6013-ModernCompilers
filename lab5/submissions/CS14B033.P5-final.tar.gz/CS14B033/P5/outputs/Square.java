class Square { 
public static void main ( String [ ] a ) { 
int t6 ; 
arraysquare Square_var128 ; 
b main_b_temp10 ; 
int main_b_temp11 ; 
b var17 ; 
int Square_c19 ; 
var17 = new b ( ) ; 
main_b_temp10 = var17 ; 
Square_var128 = new a ( ) ; 
Square_c19 = Square_var128 . sqr ( ) ; 
main_b_temp11 = Square_c19 ; 
t6 = main_b_temp11 ; 
System.out.println ( t6 ) ; 
} 
} 
class arraysquare { 
public int sqr ( ) { 
int[] anArray3 ; 
int sum4 ; 
int j5 ; 
j5 = 0 ; 
return j5 ; 
} 
} 
class a extends arraysquare { 
public int sqr ( ) { 
int c0 ; 
c0 = 9 ; 
return c0 ; 
} 
} 
class b { 
public int tp ( ) { 
int c1 ; 
arraysquare var12 ; 
var12 = new a ( ) ; 
c1 = var12 . sqr ( ) ; 
return c1 ; 
} 
} 
 