class Test3 { 
public static void main ( String [ ] args ) { 
Test3Aux p7 ; 
int q8 ; 
q8 = 5 ; 
p7 = new Test3Aux ( ) ; 
q8 = p7 . func1 ( q8 ) ; 
} 
} 
class Test3Aux { 
int x0 ; 
public int func1 ( int n6 ) { 
int val1 ; 
int res2 ; 
int temp3 ; 
int Test3Aux_val19 ; 
int Test3Aux_res210 ; 
boolean cond15 ; 
int Test3Aux_n611 ; 
int Test3Aux_temp314 ; 
Test3Aux func1_Test3Aux_temp15 ; 
int func1_Test3Aux_temp16 ; 
boolean cond24 ; 
boolean Test3Aux_cond1512 ; 
boolean Test3Aux_cond2413 ; 
val1 = 0 ; 
cond15 = n6 < val1 ; 
cond15 = ! cond15 ; 
cond24 = val1 < n6 ; 
cond24 = ! cond24 ; 
cond15 = cond15 & cond24 ; 
if ( cond15 ) { 
res2 = 1 ; 
} 
else { 
val1 = 1 ; 
temp3 = n6 - val1 ; 
Test3Aux_n611 = temp3;
func1_Test3Aux_temp15 = this ; 
Test3Aux_val19 = 0 ; 
Test3Aux_cond1512 = Test3Aux_n611 < Test3Aux_val19 ; 
Test3Aux_cond1512 = ! Test3Aux_cond1512 ; 
Test3Aux_cond2413 = Test3Aux_val19 < Test3Aux_n611 ; 
Test3Aux_cond2413 = ! Test3Aux_cond2413 ; 
Test3Aux_cond1512 = Test3Aux_cond1512 & Test3Aux_cond2413 ; 
if ( Test3Aux_cond1512 ) { 
Test3Aux_res210 = 1 ; 
} 
else { 
Test3Aux_val19 = 1 ; 
Test3Aux_temp314 = Test3Aux_n611 - Test3Aux_val19 ; 
Test3Aux_res210 = func1_Test3Aux_temp15 . func1 ( Test3Aux_temp314 ) ; 
} 
func1_Test3Aux_temp16 = Test3Aux_res210 ; 
res2 = func1_Test3Aux_temp16 ; 
} 
return res2 ; 
} 
} 
 