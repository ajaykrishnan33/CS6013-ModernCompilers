class Test5 { 
public static void main ( String [ ] args ) { 
Child1 main_Child1_temp18 ; 
int main_Parent1_temp14 ; 
Parent1 main_Parent1_temp13 ; 
Child1 p7 ; 
int Test5_a110 ; 
int q8 ; 
Parent1 r9 ; 
int Test5_a415 ; 
int Test5_x211 ; 
int Test5_y312 ; 
int main_Child1_temp19 ; 
int Test5_x516 ; 
int Test5_y617 ; 
p7 = new Child1 ( ) ; 
r9 = new Parent1 ( ) ; 
q8 = 5 ; 
Test5_a415 = q8;
main_Child1_temp18 = p7 ; 
Test5_y617 = 2 ; 
Test5_x516 = Test5_y617 * Test5_a415 ; 
Test5_y617 = 1 ; 
Test5_x516 = Test5_x516 + Test5_y617 ; 
main_Child1_temp19 = Test5_x516 ; 
q8 = main_Child1_temp19 ; 
Test5_a110 = q8;
main_Parent1_temp13 = r9 ; 
Test5_y312 = 2 ; 
Test5_x211 = Test5_y312 * Test5_a110 ; 
main_Parent1_temp14 = Test5_x211 ; 
q8 = main_Parent1_temp14 ; 
} 
} 
class Parent1 { 
int x0 ; 
public int func1 ( int a1 ) { 
int x2 ; 
int y3 ; 
y3 = 2 ; 
x2 = y3 * a1 ; 
return x2 ; 
} 
} 
class Child1 { 
public int func1 ( int a4 ) { 
int x5 ; 
int y6 ; 
y6 = 2 ; 
x5 = y6 * a4 ; 
y6 = 1 ; 
x5 = x5 + y6 ; 
return x5 ; 
} 
} 
 