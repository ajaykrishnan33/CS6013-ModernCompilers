class TC1 { 
public static void main ( String [ ] args ) { 
C1 c0 ; 
int y1 ; 
int TC1_x23 ; 
C1 main_C1_temp4 ; 
int main_C1_temp5 ; 
c0 = new C1 ( ) ; 
y1 = 10 ; 
TC1_x23 = y1;
main_C1_temp4 = c0 ; 
main_C1_temp5 = TC1_x23 ; 
y1 = main_C1_temp5 ; 
} 
} 
class C1 { 
public int get ( int x2 ) { 
return x2 ; 
} 
} 
 