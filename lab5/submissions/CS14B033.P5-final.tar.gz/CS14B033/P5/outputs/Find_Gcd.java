class Find_Gcd { 
public static void main ( String [ ] a ) { 
int main_Gcd_temp27 ; 
Gcd main_Gcd_temp26 ; 
boolean Find_Gcd_findgcd_Gcd_temp1621 ; 
boolean Find_Gcd_Gcd_retval91122 ; 
Gcd m3 ; 
boolean Find_Gcd_a417 ; 
int Find_Gcd_n1518 ; 
int Find_Gcd_n2619 ; 
Gcd Find_Gcd_findgcd_Gcd_temp1520 ; 
int x0 ; 
int y1 ; 
int z2 ; 
int Find_Gcd_Gcd_aux0281423 ; 
int Find_Gcd_Gcd_num171324 ; 
int Find_Gcd_Gcd_num2101225 ; 
x0 = 10 ; 
y1 = 15 ; 
m3 = new Gcd ( ) ; 
Find_Gcd_n1518 = x0;
Find_Gcd_n2619 = y1;
main_Gcd_temp26 = m3 ; 
Find_Gcd_Gcd_num171324 = Find_Gcd_n1518;
Find_Gcd_Gcd_num2101225 = Find_Gcd_n2619;
Find_Gcd_findgcd_Gcd_temp1520 = main_Gcd_temp26 ; 
Find_Gcd_Gcd_retval91122 = false ; 
Find_Gcd_Gcd_aux0281423 = Find_Gcd_Gcd_num2101225 ; 
Find_Gcd_findgcd_Gcd_temp1621 = Find_Gcd_Gcd_retval91122 ; 
Find_Gcd_a417 = Find_Gcd_findgcd_Gcd_temp1621 ; 
while ( Find_Gcd_a417 ) { 
if ( Find_Gcd_a417 ) Find_Gcd_n1518 = Find_Gcd_n1518 - Find_Gcd_n2619 ; 
else Find_Gcd_n2619 = Find_Gcd_n2619 - Find_Gcd_n1518 ; 
} 
main_Gcd_temp27 = Find_Gcd_n1518 ; 
z2 = main_Gcd_temp27 ; 
System.out.println ( z2 ) ; 
} 
} 
class Gcd { 
public int findgcd ( int n15 , int n26 ) { 
boolean Gcd_retval911 ; 
boolean a4 ; 
int Gcd_num21012 ; 
Gcd findgcd_Gcd_temp15 ; 
int Gcd_num1713 ; 
boolean findgcd_Gcd_temp16 ; 
int Gcd_aux02814 ; 
Gcd_num1713 = n15;
Gcd_num21012 = n26;
findgcd_Gcd_temp15 = this ; 
Gcd_retval911 = false ; 
Gcd_aux02814 = Gcd_num21012 ; 
findgcd_Gcd_temp16 = Gcd_retval911 ; 
a4 = findgcd_Gcd_temp16 ; 
while ( a4 ) { 
if ( a4 ) n15 = n15 - n26 ; 
else n26 = n26 - n15 ; 
} 
return n15 ; 
} 
public boolean Compare ( int num17 , int num210 ) { 
int aux028 ; 
boolean retval9 ; 
retval9 = false ; 
aux028 = num210 ; 
return retval9 ; 
} 
} 
 