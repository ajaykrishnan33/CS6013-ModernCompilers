class Test2 {
	public static void main ( String [ ] args ) {
		int Test2_Test2Aux_a11016 ;
		int Test2_Test2Aux_b21117 ;
		int Test2_q519 ;
		int main_Test2Aux_temp24 ;
		Test2Aux main_Test2Aux_temp23 ;
		Test2Aux p7 ;
		int q8 ;
		int Test2_Test2Aux_prod31215 ;
		int r9 ;
		int Test2_a418 ;
		int Test2_b620 ;
		int Test2_func2_Test2Aux_temp1421 ;
		Test2Aux Test2_func2_Test2Aux_temp1322 ;
		q8 = 5 ;
		r9 = 7 ;
		p7 = new Test2Aux ( ) ;
		Test2_a418 = q8;
		Test2_b620 = r9;
		main_Test2Aux_temp23 = p7 ;
		Test2_Test2Aux_a11016 = Test2_a418;
		Test2_Test2Aux_b21117 = Test2_b620;
		Test2_func2_Test2Aux_temp1322 = main_Test2Aux_temp23 ;
		Test2_func2_Test2Aux_temp1322.x0 = Test2_Test2Aux_a11016 + Test2_Test2Aux_b21117 ;
		Test2_Test2Aux_prod31215 = Test2_Test2Aux_a11016 * Test2_Test2Aux_b21117 ;
		Test2_func2_Test2Aux_temp1421 = Test2_Test2Aux_prod31215 ;
		Test2_q519 = Test2_func2_Test2Aux_temp1421 ;
		main_Test2Aux_temp24 = Test2_q519 ;
		q8 = main_Test2Aux_temp24 ;
	}
}
class Test2Aux {
	int x0 ;
	public int func1 ( int a1 , int b2 ) {
		int prod3 ;
		x0 = a1 + b2 ;
		prod3 = a1 * b2 ;
		return prod3 ;
	}
	public int func2 ( int a4 , int b6 ) {
		int Test2Aux_a110 ;
		int Test2Aux_b211 ;
		int q5 ;
		int Test2Aux_prod312 ;
		int func2_Test2Aux_temp14 ;
		Test2Aux func2_Test2Aux_temp13 ;
		Test2Aux_a110 = a4;
		Test2Aux_b211 = b6;
		func2_Test2Aux_temp13 = this ;
		func2_Test2Aux_temp13.x0 = Test2Aux_a110 + Test2Aux_b211 ;
		Test2Aux_prod312 = Test2Aux_a110 * Test2Aux_b211 ;
		func2_Test2Aux_temp14 = Test2Aux_prod312 ;
		q5 = func2_Test2Aux_temp14 ;
		return q5 ;
	}
}
