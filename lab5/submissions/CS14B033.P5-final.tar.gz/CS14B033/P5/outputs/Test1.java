class Test1 {
	public static void main ( String [ ] args ) {
		int main_Test1Aux_temp24 ;
		int Test1_x915 ;
		Test1Aux main_Test1Aux_temp23 ;
		int Test1_Test1Aux_prod61016 ;
		Test1Aux Test1_func2_Test1Aux_temp1320 ;
		int Test1_Test1Aux_b51221 ;
		int Test1_Test1Aux_a41122 ;
		Test1Aux p0 ;
		int q1 ;
		int r2 ;
		int Test1_a717 ;
		int Test1_b818 ;
		int Test1_func2_Test1Aux_temp1419 ;
		q1 = 5 ;
		r2 = 7 ;
		p0 = new Test1Aux ( ) ;
		Test1_a717 = q1;
		Test1_b818 = r2;
		main_Test1Aux_temp23 = p0 ;
		Test1_Test1Aux_a41122 = Test1_a717;
		Test1_Test1Aux_b51221 = Test1_b818;
		Test1_func2_Test1Aux_temp1320 = null ;
		Test1_Test1Aux_prod61016 = Test1_Test1Aux_a41122 * Test1_Test1Aux_b51221 ;
		Test1_func2_Test1Aux_temp1419 = Test1_Test1Aux_prod61016 ;
		Test1_x915 = Test1_func2_Test1Aux_temp1419 ;
		main_Test1Aux_temp24 = Test1_a717 ;
		q1 = main_Test1Aux_temp24 ;
		System.out.println ( q1 ) ;
	}
}
class Test1Aux {
	int x3 ;
	public int func1 ( int a4 , int b5 ) {
		int prod6 ;
		prod6 = a4 * b5 ;
		return prod6 ;
	}
	public int func2 ( int a7 , int b8 ) {
		int Test1Aux_prod610 ;
		int Test1Aux_a411 ;
		int Test1Aux_b512 ;
		int func2_Test1Aux_temp14 ;
		int x9 ;
		Test1Aux func2_Test1Aux_temp13 ;
		Test1Aux_a411 = a7;
		Test1Aux_b512 = b8;
		func2_Test1Aux_temp13 = null ;
		Test1Aux_prod610 = Test1Aux_a411 * Test1Aux_b512 ;
		func2_Test1Aux_temp14 = Test1Aux_prod610 ;
		x9 = func2_Test1Aux_temp14 ;
		return a7 ;
	}
}
