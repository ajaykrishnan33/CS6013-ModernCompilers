class Test2 { 
public static void main ( String [ ] args ) { 
int main_Test2Aux_temp12 ; 
int func2_Test2Aux_temp10 ; 
Test2Aux main_Test2Aux_temp11 ; 
int Test2Aux_func1_temp0 ; 
Test2Aux Test2_main_temp6 ; 
int Test2_main_temp7 ; 
int Test2_main_temp8 ; 
int Test2Aux_func1_temp2 ; 
int Test2Aux_func1_temp1 ; 
int Test2Aux_func2_temp4 ; 
int Test2Aux_func2_temp5 ; 
int Test2Aux_func2_temp3 ; 
Test2Aux func2_Test2Aux_temp9 ; 
Test2_main_temp7 = 5 ; 
Test2_main_temp8 = 7 ; 
Test2_main_temp6 = new Test2Aux ( ) ; 
Test2Aux_func2_temp3 = Test2_main_temp7;
Test2Aux_func2_temp5 = Test2_main_temp8;
main_Test2Aux_temp11 = Test2_main_temp6 ; 
Test2Aux_func1_temp0 = Test2Aux_func2_temp3;
Test2Aux_func1_temp1 = Test2Aux_func2_temp5;
func2_Test2Aux_temp9 = new Test2Aux() ; 
func2_Test2Aux_temp9.Test2Aux_temp0 = Test2Aux_func1_temp0 + Test2Aux_func1_temp1 ; 
Test2Aux_func1_temp2 = Test2Aux_func1_temp0 * Test2Aux_func1_temp1 ; 
func2_Test2Aux_temp10 = Test2Aux_func1_temp2 ; 
Test2Aux_func2_temp4 = func2_Test2Aux_temp10 ; 
main_Test2Aux_temp12 = Test2Aux_func2_temp4 ; 
Test2_main_temp7 = main_Test2Aux_temp12 ; 
} 
} 
class Test2Aux { 
int Test2Aux_temp0 ; 
public int func1 ( int Test2Aux_func1_temp0 , int Test2Aux_func1_temp1 ) { 
int Test2Aux_func1_temp2 ; 
Test2Aux_temp0 = Test2Aux_func1_temp0 + Test2Aux_func1_temp1 ; 
Test2Aux_func1_temp2 = Test2Aux_func1_temp0 * Test2Aux_func1_temp1 ; 
return Test2Aux_func1_temp2 ; 
} 
public int func2 ( int Test2Aux_func2_temp3 , int Test2Aux_func2_temp5 ) { 
int Test2Aux_func2_temp4 ; 
int Test2Aux_func1_temp2 ; 
int func2_Test2Aux_temp10 ; 
int Test2Aux_func1_temp1 ; 
int Test2Aux_func1_temp0 ; 
Test2Aux func2_Test2Aux_temp9 ; 
Test2Aux_func1_temp0 = Test2Aux_func2_temp3;
Test2Aux_func1_temp1 = Test2Aux_func2_temp5;
func2_Test2Aux_temp9 = new Test2Aux() ; 
func2_Test2Aux_temp9.Test2Aux_temp0 = Test2Aux_func1_temp0 + Test2Aux_func1_temp1 ; 
Test2Aux_func1_temp2 = Test2Aux_func1_temp0 * Test2Aux_func1_temp1 ; 
func2_Test2Aux_temp10 = Test2Aux_func1_temp2 ; 
Test2Aux_func2_temp4 = func2_Test2Aux_temp10 ; 
return Test2Aux_func2_temp4 ; 
} 
} 
 