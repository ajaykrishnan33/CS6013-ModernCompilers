class Test4 { 
public static void main ( String [ ] args ) { 
Child Test4_main_temp9 ; 
int Test4_main_temp10 ; 
int a ; 
Child main_Child_temp17 ; 
int main_Child_temp18 ; 
int y ; 
int m ; 
Test4_main_temp9 = new Child ( ) ; 
Test4_main_temp10 = 5 ; 
Child_func1_temp11 = Test4_main_temp10;
main_Child_temp17 = Test4_main_temp9 ; 
Child_func1_temp12 = 2 ; 
Child_func1_temp13 = Child_func1_temp12 * Child_func1_temp11 ; 
Child_func1_temp12 = 1 ; 
Child_func1_temp13 = Child_func1_temp13 + Child_func1_temp12 ; 
main_Child_temp18 = Child_func1_temp13 ; 
Test4_main_temp10 = main_Child_temp18 ; 
Test4_main_temp10 = Test4_main_temp9 . func3 ( Test4_main_temp10 ) ; 
} 
} 
class Parent { 
int Parent_temp0 ; 
public int func1 ( int Parent_func1_temp3 ) { 
int Parent_func1_temp4 ; 
int Parent_func1_temp5 ; 
Parent_func1_temp4 = 2 ; 
Parent_func1_temp5 = Parent_func1_temp4 * Parent_func1_temp3 ; 
return Parent_func1_temp5 ; 
} 
public int func3 ( int Parent_func3_temp6 ) { 
int Parent_func3_temp7 ; 
int Parent_func3_temp8 ; 
Parent_func3_temp7 = 2 ; 
Parent_func3_temp8 = Parent_func3_temp7 * Parent_func3_temp6 ; 
Parent_func3_temp7 = 1 ; 
Parent_func3_temp8 = Parent_func3_temp8 + Parent_func3_temp7 ; 
return Parent_func3_temp8 ; 
} 
} 
class Child extends Parent { 
public int func1 ( int Child_func1_temp11 ) { 
int Child_func1_temp12 ; 
int Child_func1_temp13 ; 
Child_func1_temp12 = 2 ; 
Child_func1_temp13 = Child_func1_temp12 * Child_func1_temp11 ; 
Child_func1_temp12 = 1 ; 
Child_func1_temp13 = Child_func1_temp13 + Child_func1_temp12 ; 
return Child_func1_temp13 ; 
} 
public int func2 ( int Child_func2_temp14 ) { 
int Child_func2_temp15 ; 
int Child_func2_temp16 ; 
Child_func2_temp15 = 2 ; 
Child_func2_temp16 = Child_func2_temp15 * Child_func2_temp14 ; 
Child_func2_temp15 = 1 ; 
Child_func2_temp16 = Child_func2_temp16 + Child_func2_temp15 ; 
return Child_func2_temp16 ; 
} 
} 
class Wild extends Child { 
public int func3 ( int Wild_func3_temp0 ) { 
int Wild_func3_temp1 ; 
int Wild_func3_temp2 ; 
Wild_func3_temp1 = 2 ; 
Wild_func3_temp2 = Wild_func3_temp1 * Wild_func3_temp0 ; 
Wild_func3_temp1 = 1 ; 
Wild_func3_temp2 = Wild_func3_temp2 + Wild_func3_temp1 ; 
return Wild_func3_temp2 ; 
} 
} 
 