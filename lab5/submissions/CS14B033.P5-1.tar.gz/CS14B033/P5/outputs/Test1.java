class Test1 {
	public static void main ( String [ ] args ) {
		Test1Aux func2_Test1Aux_temp9 ;
		int Test1Aux_func1_temp4 ;
		Test1Aux main_Test1Aux_temp11 ;
		int Test1Aux_func1_temp5 ;
		int main_Test1Aux_temp12 ;
		int Test1Aux_func2_temp7 ;
		int Test1Aux_func1_temp3 ;
		int Test1Aux_func2_temp8 ;
		int func2_Test1Aux_temp10 ;
		int Test1Aux_func2_temp6 ;
		Test1Aux Test1_main_temp0 ;
		int Test1_main_temp1 ;
		int Test1_main_temp2 ;
		Test1_main_temp1 = 5 ;
		Test1_main_temp2 = 7 ;
		Test1_main_temp0 = new Test1Aux ( ) ;
		Test1Aux_func2_temp6 = Test1_main_temp1;
		Test1Aux_func2_temp7 = Test1_main_temp2;
		main_Test1Aux_temp11 = Test1_main_temp0 ;
		Test1Aux_func1_temp3 = Test1Aux_func2_temp6;
		Test1Aux_func1_temp4 = Test1Aux_func2_temp7;
		func2_Test1Aux_temp9 = new Test1Aux() ;
		func2_Test1Aux_temp9.Test1Aux_temp0 = Test1Aux_func1_temp3 + Test1Aux_func1_temp4 ;
		Test1Aux_func1_temp5 = Test1Aux_func1_temp3 * Test1Aux_func1_temp4 ;
		func2_Test1Aux_temp10 = Test1Aux_func1_temp5 ;
		Test1Aux_func2_temp8 = func2_Test1Aux_temp10 ;
		main_Test1Aux_temp12 = Test1Aux_func2_temp6 ;
		Test1_main_temp1 = main_Test1Aux_temp12 ;
		System.out.println ( Test1_main_temp1 ) ;
	}
}
class Test1Aux {
	int Test1Aux_temp0 ;
	public int func1 ( int Test1Aux_func1_temp3 , int Test1Aux_func1_temp4 ) {
		int Test1Aux_func1_temp5 ;
		Test1Aux_temp0 = Test1Aux_func1_temp3 + Test1Aux_func1_temp4 ;
		Test1Aux_func1_temp5 = Test1Aux_func1_temp3 * Test1Aux_func1_temp4 ;
		return Test1Aux_func1_temp5 ;
	}
	public int func2 ( int Test1Aux_func2_temp6 , int Test1Aux_func2_temp7 ) {
		Test1Aux func2_Test1Aux_temp9 ;
		int Test1Aux_func1_temp4 ;
		int Test1Aux_func1_temp5 ;
		int Test1Aux_func1_temp3 ;
		int Test1Aux_func2_temp8 ;
		int func2_Test1Aux_temp10 ;
		Test1Aux_func2_temp8 = this . func1 ( Test1Aux_func2_temp6 , Test1Aux_func2_temp7 ) ;
		return Test1Aux_func2_temp6 ;
	}
}
