class Test3 { 
public static void main ( String [ ] args ) { 
Test3Aux Test3_main_temp6 ; 
int Test3_main_temp7 ; 
Test3_main_temp7 = 5 ; 
Test3_main_temp6 = new Test3Aux ( ) ; 
Test3_main_temp7 = Test3_main_temp6 . func1 ( Test3_main_temp7 ) ; 
} 
} 
class Test3Aux { 
int Test3Aux_temp0 ; 
public int func1 ( int Test3Aux_func1_temp5 ) { 
int Test3Aux_func1_temp0 ; 
int Test3Aux_func1_temp1 ; 
int Test3Aux_func1_temp2 ; 
int func1_Test3Aux_temp9 ; 
boolean Test3Aux_func1_temp3 ; 
Test3Aux func1_Test3Aux_temp8 ; 
boolean Test3Aux_func1_temp4 ; 
Test3Aux_func1_temp0 = 0 ; 
Test3Aux_func1_temp4 = Test3Aux_func1_temp5 < Test3Aux_func1_temp0 ; 
Test3Aux_func1_temp4 = ! Test3Aux_func1_temp4 ; 
Test3Aux_func1_temp3 = Test3Aux_func1_temp0 < Test3Aux_func1_temp5 ; 
Test3Aux_func1_temp3 = ! Test3Aux_func1_temp3 ; 
Test3Aux_func1_temp4 = Test3Aux_func1_temp4 & Test3Aux_func1_temp3 ; 
if ( Test3Aux_func1_temp4 ) { 
Test3Aux_func1_temp1 = 1 ; 
} 
else { 
Test3Aux_func1_temp0 = 1 ; 
Test3Aux_func1_temp2 = Test3Aux_func1_temp5 - Test3Aux_func1_temp0 ; 
Test3Aux_func1_temp5 = Test3Aux_func1_temp2;
func1_Test3Aux_temp8 = new Test3Aux() ; 
Test3Aux_func1_temp0 = 0 ; 
Test3Aux_func1_temp4 = Test3Aux_func1_temp5 < Test3Aux_func1_temp0 ; 
Test3Aux_func1_temp4 = ! Test3Aux_func1_temp4 ; 
Test3Aux_func1_temp3 = Test3Aux_func1_temp0 < Test3Aux_func1_temp5 ; 
Test3Aux_func1_temp3 = ! Test3Aux_func1_temp3 ; 
Test3Aux_func1_temp4 = Test3Aux_func1_temp4 & Test3Aux_func1_temp3 ; 
if ( Test3Aux_func1_temp4 ) { 
Test3Aux_func1_temp1 = 1 ; 
} 
else { 
Test3Aux_func1_temp0 = 1 ; 
Test3Aux_func1_temp2 = Test3Aux_func1_temp5 - Test3Aux_func1_temp0 ; 
Test3Aux_func1_temp1 = func1_Test3Aux_temp8 . func1 ( Test3Aux_func1_temp2 ) ; 
} 
func1_Test3Aux_temp9 = Test3Aux_func1_temp1 ; 
Test3Aux_func1_temp1 = func1_Test3Aux_temp9 ; 
} 
return Test3Aux_func1_temp1 ; 
} 
} 
 