class Test5 {
	public static void main ( String [ ] args ) {
		Child1 main_Child1_temp5 ;
		int main_Child1_temp6 ;
		int main_Parent1_temp4 ;
		int Child1_func1_temp0 ;
		int Child1_func1_temp1 ;
		int Child1_func1_temp2 ;
		Parent1 main_Parent1_temp3 ;
		Child1 Test5_main_temp0 ;
		int Test5_main_temp1 ;
		Parent1 Test5_main_temp2 ;
		int Parent1_func1_temp0 ;
		int Parent1_func1_temp1 ;
		int Parent1_func1_temp2 ;
		
		Test5_main_temp0 = new Child1 ( ) ;
		Test5_main_temp2 = new Parent1 ( ) ;
		Test5_main_temp1 = 5 ;
		Child1_func1_temp0 = Test5_main_temp1;
		main_Child1_temp5 = Test5_main_temp0 ;
		Child1_func1_temp2 = 2 ;
		Child1_func1_temp1 = Child1_func1_temp2 * Child1_func1_temp0 ;
		Child1_func1_temp2 = 1 ;
		Child1_func1_temp1 = Child1_func1_temp1 + Child1_func1_temp2 ;
		main_Child1_temp6 = Child1_func1_temp1 ;
		Test5_main_temp1 = main_Child1_temp6 ;
		Parent1_func1_temp0 = Test5_main_temp1;
		main_Parent1_temp3 = Test5_main_temp2 ;
		Parent1_func1_temp2 = 2 ;
		Parent1_func1_temp1 = Parent1_func1_temp2 * Parent1_func1_temp0 ;
		main_Parent1_temp4 = Parent1_func1_temp1 ;
		Test5_main_temp1 = main_Parent1_temp4 ;
	}
}
class Parent1 {
	int Parent1_temp0 ;
	public int func1 ( int Parent1_func1_temp0 ) {
		int Parent1_func1_temp1 ;
		int Parent1_func1_temp2 ;
		Parent1_func1_temp2 = 2 ;
		Parent1_func1_temp1 = Parent1_func1_temp2 * Parent1_func1_temp0 ;
		return Parent1_func1_temp1 ;
	}
}
class Child1 {
	public int func1 ( int Child1_func1_temp0 ) {
		int Child1_func1_temp1 ;
		int Child1_func1_temp2 ;
		Child1_func1_temp2 = 2 ;
		Child1_func1_temp1 = Child1_func1_temp2 * Child1_func1_temp0 ;
		Child1_func1_temp2 = 1 ;
		Child1_func1_temp1 = Child1_func1_temp1 + Child1_func1_temp2 ;
		return Child1_func1_temp1 ;
	}
}
