package helper;

import java.util.*;

public class GlobalSymTab {

	public static HashMap<String, ClassSymTab> classes = new HashMap<String, ClassSymTab>();
	public static int count = 0;

	public static ClassSymTab addClass(String name, String parent) {
		if(classes.containsKey(name))
			return classes.get(name);
		ClassSymTab clst = new ClassSymTab(name, parent);
		classes.put(name, clst);
		return clst;
	}

	public static ClassSymTab addClass(String name) {
		if(classes.containsKey(name))
			return classes.get(name);
		ClassSymTab clst = new ClassSymTab(name);
		classes.put(name, clst);
		return clst;
	}

	public static void renameAll(){
		for(Map.Entry<String, ClassSymTab> entry: classes.entrySet()){
			entry.getValue().renameAll();
		}
	}

	private static boolean hasChildFunc(String type, String func){
		ClassSymTab p = classes.get(type);
		if(p.functions.containsKey(func))
			return true;
		boolean flag = false;
		for(String child: p.children){
			if(hasChildFunc(child, func))
				return true;
		}
		return false;
	}

	public static FuncSymTab inlinable(String type, String func){
		ClassSymTab clst = classes.get(type);
		
		for(String child: clst.children){
			if(hasChildFunc(child, func))
				return null;
		}
		// if inlinable
		while(true){
			if(clst.functions.containsKey(func))
				return clst.functions.get(func);
			if(clst.parent==null)
				break;
			clst = classes.get(clst.parent);
		}

		return null;
	}

	public static void inlineAll(){
		for(Map.Entry<String, ClassSymTab> entry: classes.entrySet()){
			entry.getValue().inlineAll();
		}
	}

	public static void printDebug(){
		for(Map.Entry<String, ClassSymTab> entry: classes.entrySet()){
			System.out.println(entry.getKey()+":");
			entry.getValue().printDebug();
		}
	}

	public static void unvisitAll(){
		for(Map.Entry<String, ClassSymTab> entry: classes.entrySet()){
			entry.getValue().unvisitAll();
		}	
	}

}