class Test1 {
	public static void main ( String [ ] args ) {
		int main_Test1Aux_temp13 ;
		int Test1_x9 ;
		int Test1_Test1Aux_a4 ;
		int Test1_Test1Aux_b5 ;
		int Test1_Test1Aux_prod6 ;
		Test1Aux main_Test1Aux_temp12 ;
		Test1Aux Test1_func2_Test1Aux_temp10 ;
		int Test1_func2_Test1Aux_temp11 ;
		Test1Aux p0 ;
		int q1 ;
		int r2 ;
		int Test1_a7 ;
		int Test1_b8 ;
		q1 = 5 ;
		r2 = 7 ;
		p0 = new Test1Aux ( ) ;
		Test1_a7 = q1;
		Test1_b8 = r2;
		main_Test1Aux_temp12 = p0 ;
		a4 = Test1_a7;
		b5 = Test1_b8;
		func2_Test1Aux_temp10 = this ;
		func2_Test1Aux_temp10.x3 = a4 + b5 ;
		prod6 = a4 * b5 ;
		func2_Test1Aux_temp11 = prod6 ;
		Test1_x9 = func2_Test1Aux_temp11 ;
		main_Test1Aux_temp13 = Test1_a7 ;
		q1 = main_Test1Aux_temp13 ;
		System.out.println ( q1 ) ;
	}
}
class Test1Aux {
	int x3 ;
	public int func1 ( int a4 , int b5 ) {
		int prod6 ;
		x3 = a4 + b5 ;
		prod6 = a4 * b5 ;
		return prod6 ;
	}
	public int func2 ( int a7 , int b8 ) {
		int Test1Aux_prod6 ;
		int Test1Aux_a4 ;
		int Test1Aux_b5 ;
		int x9 ;
		Test1Aux func2_Test1Aux_temp10 ;
		int func2_Test1Aux_temp11 ;
		Test1Aux_a4 = a7;
		Test1Aux_b5 = b8;
		func2_Test1Aux_temp10 = this ;
		func2_Test1Aux_temp10.x3 = Test1Aux_a4 + Test1Aux_b5 ;
		Test1Aux_prod6 = Test1Aux_a4 * Test1Aux_b5 ;
		func2_Test1Aux_temp11 = Test1Aux_prod6 ;
		x9 = func2_Test1Aux_temp11 ;
		return a7 ;
	}
}
