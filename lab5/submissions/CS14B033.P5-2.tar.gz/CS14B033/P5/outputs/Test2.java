class Test2 { 
public static void main ( String [ ] args ) { 
Test2Aux p7 ; 
int q8 ; 
int r9 ; 
int Test2_a4 ; 
int Test2_q5 ; 
int Test2_b6 ; 
int main_Test2Aux_temp11 ; 
Test2Aux main_Test2Aux_temp10 ; 
q8 = 5 ; 
r9 = 7 ; 
p7 = new Test2Aux ( ) ; 
Test2_a4 = q8;
Test2_b6 = r9;
main_Test2Aux_temp10 = p7 ; 
Test2_q5 = main_Test2Aux_temp10 . func1 ( Test2_a4 , Test2_b6 ) ; 
main_Test2Aux_temp11 = Test2_q5 ; 
q8 = main_Test2Aux_temp11 ; 
} 
} 
class Test2Aux { 
int x0 ; 
public int func1 ( int a1 , int b2 ) { 
int prod3 ; 
x0 = a1 + b2 ; 
prod3 = a1 * b2 ; 
return prod3 ; 
} 
public int func2 ( int a4 , int b6 ) { 
int q5 ; 
q5 = this . func1 ( a4 , b6 ) ; 
return q5 ; 
} 
} 
 