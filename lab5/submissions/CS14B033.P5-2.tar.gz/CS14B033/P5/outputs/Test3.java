class Test3 { 
public static void main ( String [ ] args ) { 
Test3Aux p7 ; 
int q8 ; 
q8 = 5 ; 
p7 = new Test3Aux ( ) ; 
q8 = p7 . func1 ( q8 ) ; 
} 
} 
class Test3Aux { 
int x0 ; 
public int func1 ( int n6 ) { 
int val1 ; 
int res2 ; 
int temp3 ; 
Test3Aux func1_Test3Aux_temp9 ; 
int Test3Aux_val1 ; 
int Test3Aux_res2 ; 
boolean cond15 ; 
int Test3Aux_n6 ; 
int func1_Test3Aux_temp10 ; 
int Test3Aux_temp3 ; 
boolean cond24 ; 
boolean Test3Aux_cond15 ; 
boolean Test3Aux_cond24 ; 
val1 = 0 ; 
cond15 = n6 < val1 ; 
cond15 = ! cond15 ; 
cond24 = val1 < n6 ; 
cond24 = ! cond24 ; 
cond15 = cond15 & cond24 ; 
if ( cond15 ) { 
res2 = 1 ; 
} 
else { 
val1 = 1 ; 
temp3 = n6 - val1 ; 
Test3Aux_n6 = temp3;
func1_Test3Aux_temp9 = this ; 
Test3Aux_val1 = 0 ; 
Test3Aux_cond15 = Test3Aux_n6 < Test3Aux_val1 ; 
Test3Aux_cond15 = ! Test3Aux_cond15 ; 
Test3Aux_cond24 = Test3Aux_val1 < Test3Aux_n6 ; 
Test3Aux_cond24 = ! Test3Aux_cond24 ; 
Test3Aux_cond15 = Test3Aux_cond15 & Test3Aux_cond24 ; 
if ( Test3Aux_cond15 ) { 
Test3Aux_res2 = 1 ; 
} 
else { 
Test3Aux_val1 = 1 ; 
Test3Aux_temp3 = Test3Aux_n6 - Test3Aux_val1 ; 
Test3Aux_res2 = func1_Test3Aux_temp9 . func1 ( Test3Aux_temp3 ) ; 
} 
func1_Test3Aux_temp10 = Test3Aux_res2 ; 
res2 = func1_Test3Aux_temp10 ; 
} 
return res2 ; 
} 
} 
 