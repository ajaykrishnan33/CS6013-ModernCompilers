class Test4 { 
public static void main ( String [ ] args ) { 
Child p10 ; 
int q11 ; 
int Test4_m14 ; 
int Test4_a12 ; 
Child main_Child_temp18 ; 
int main_Child_temp19 ; 
int Test4_y13 ; 
p10 = new Child ( ) ; 
q11 = 5 ; 
Test4_a12 = q11;
main_Child_temp18 = p10 ; 
Test4_y13 = 2 ; 
Test4_m14 = Test4_y13 * Test4_a12 ; 
Test4_y13 = 1 ; 
Test4_m14 = Test4_m14 + Test4_y13 ; 
main_Child_temp19 = Test4_m14 ; 
q11 = main_Child_temp19 ; 
q11 = p10 . func3 ( q11 ) ; 
} 
} 
class Parent { 
int m3 ; 
public int func1 ( int a4 ) { 
int y5 ; 
int m6 ; 
y5 = 2 ; 
m6 = y5 * a4 ; 
return m6 ; 
} 
public int func3 ( int a7 ) { 
int y8 ; 
int m9 ; 
y8 = 2 ; 
m9 = y8 * a7 ; 
y8 = 1 ; 
m9 = m9 + y8 ; 
return m9 ; 
} 
} 
class Child extends Parent { 
public int func1 ( int a12 ) { 
int y13 ; 
int m14 ; 
y13 = 2 ; 
m14 = y13 * a12 ; 
y13 = 1 ; 
m14 = m14 + y13 ; 
return m14 ; 
} 
public int func2 ( int a15 ) { 
int y16 ; 
int m17 ; 
y16 = 2 ; 
m17 = y16 * a15 ; 
y16 = 1 ; 
m17 = m17 + y16 ; 
return m17 ; 
} 
} 
class Wild extends Child { 
public int func3 ( int a0 ) { 
int y1 ; 
int m2 ; 
y1 = 2 ; 
m2 = y1 * a0 ; 
y1 = 1 ; 
m2 = m2 + y1 ; 
return m2 ; 
} 
} 
 