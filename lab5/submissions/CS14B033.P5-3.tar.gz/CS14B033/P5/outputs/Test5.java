class Test5 { 
public static void main ( String [ ] args ) { 
Parent1 main_Parent1_temp10 ; 
int main_Parent1_temp11 ; 
Child1 main_Child1_temp12 ; 
int main_Child1_temp13 ; 
Child1 p7 ; 
int Test5_a1 ; 
int q8 ; 
Parent1 r9 ; 
int Test5_a4 ; 
int Test5_x2 ; 
int Test5_y3 ; 
int Test5_x5 ; 
int Test5_y6 ; 
p7 = new Child1 ( ) ; 
r9 = new Parent1 ( ) ; 
q8 = 5 ; 
Test5_a4 = q8;
main_Child1_temp12 = p7 ; 
Test5_y6 = 2 ; 
Test5_x5 = Test5_y6 * Test5_a4 ; 
Test5_y6 = 1 ; 
Test5_x5 = Test5_x5 + Test5_y6 ; 
main_Child1_temp13 = Test5_x5 ; 
q8 = main_Child1_temp13 ; 
Test5_a1 = q8;
main_Parent1_temp10 = r9 ; 
Test5_y3 = 2 ; 
Test5_x2 = Test5_y3 * Test5_a1 ; 
main_Parent1_temp11 = Test5_x2 ; 
q8 = main_Parent1_temp11 ; 
} 
} 
class Parent1 { 
int x0 ; 
public int func1 ( int a1 ) { 
int x2 ; 
int y3 ; 
y3 = 2 ; 
x2 = y3 * a1 ; 
return x2 ; 
} 
} 
class Child1 { 
public int func1 ( int a4 ) { 
int x5 ; 
int y6 ; 
y6 = 2 ; 
x5 = y6 * a4 ; 
y6 = 1 ; 
x5 = x5 + y6 ; 
return x5 ; 
} 
} 
 